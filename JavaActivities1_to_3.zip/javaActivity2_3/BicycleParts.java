package javaActivity2_3;

interface BicycleParts {
	public int gears =0;
	public int speed = 0;
}
