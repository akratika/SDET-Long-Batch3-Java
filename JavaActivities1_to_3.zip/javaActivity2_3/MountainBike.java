package javaActivity2_3;

class MountainBike extends Bicycle{
	public int seatHeight;

	public MountainBike(int gears, int speed, int height) {
		super(gears, speed);
		seatHeight = height;
	}
	public void seatHeight(int newvalue) {
		seatHeight = newvalue;
	}
	public String bicycleDesc() {
		return ("Number of gears: "+ gears+ "\nCurrent Speed of Bicycle: "+ speed+"\nSeat Height of Bicycle: "+seatHeight);
	}
}
