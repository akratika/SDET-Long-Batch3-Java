package javaActivity2_3;

class Bicycle implements BicycleParts, BicycleOperations{
	public int gears, speed;
	
	public Bicycle(int gears, int speed){
		this.gears = gears;
		this.speed = speed;
	}
	public void applyBrake(int decrement) {
		speed -= decrement;
		System.out.println("Reduced speed is:" + speed);
	}
	public void speedUp(int increment) {
		speed += increment;
		System.out.println("Accelerated Speed is: "+ speed);
	}
	public String bicycleDesc() {
		return ("Number of gears: "+ gears+"\nCurrent Speed of Bicycle: "+ speed);
	}
}
