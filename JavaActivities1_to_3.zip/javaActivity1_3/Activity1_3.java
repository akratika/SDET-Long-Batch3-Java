package javaActivity1_3;

public class Activity1_3 {

	/*
	 * Create a variable named seconds and initialize it to 1000000000
	 * Create variables to store the time of all planets (MercurySeconds, VenusSeconds, etc.)
	 * Calculate the age on all the planets and print them.
	 */
	public static void main(String[] args) {
		
		double secondsEntry = 1000000000,
		EarthSeconds = 31557600,
		MercurySeconds = 0.2408467,
		VenusSeconds = 0.61519726,
		MarsSeconds = 1.8808158,
		JupiterSeconds= 11.862615,
		SaturnSeconds= 29.447498,
		UranusSeconds= 84.016846,
		NeptuneSeconds= 164.79132;
		
		System.out.println("Age on Mercury: "+ secondsEntry/EarthSeconds/MercurySeconds);
		System.out.println("Age on Venus: "+ secondsEntry/EarthSeconds/VenusSeconds);
		System.out.println("Age on Earth: "+ secondsEntry/EarthSeconds);
		System.out.println("Age on Mars: "+ secondsEntry/EarthSeconds/MarsSeconds);
		System.out.println("Age on Jupiter: "+ secondsEntry/EarthSeconds/JupiterSeconds);
		System.out.println("Age on Saturn: "+ secondsEntry/EarthSeconds/SaturnSeconds);
		System.out.println("Age on Uranus: "+ secondsEntry/EarthSeconds/UranusSeconds);
		System.out.println("Age on Naptune: "+ secondsEntry/EarthSeconds/NeptuneSeconds);
		
	}

}
