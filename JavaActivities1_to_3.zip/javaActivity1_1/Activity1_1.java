package javaActivity1_1;

public class Activity1_1 {
/*
 * Method to display Car characteristics
 * method is using another Class 'Car'
 */
	public static void main(String[] args) {
		
		Car jaguar = new Car();
		jaguar.make = 2014;
		jaguar.color = "Black";
		jaguar.transmission = "Manual";
		
		jaguar.displayCharacteristics();
		jaguar.accelerate();
		jaguar.brake();

	}

}
