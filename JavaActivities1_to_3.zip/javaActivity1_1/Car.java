package javaActivity1_1;

public class Car {
	String color, transmission;
	int make, tyres, doors;
	/*
	 * Constructor of Car class initialising
	 * tyres and doors
	 */
	Car(){
		tyres =4;
		doors =4;
	}
	/*
	 * Method to display Car characteristics like
	 * Color, Make, Transmission
	 * Number of doors, Number of tyres
	 */
	public void displayCharacteristics() {
		System.out.println("color of the Car: "+ color);
		System.out.println("Make of the Car: "+ make);
		System.out.println("Transmission of the Car: "+ transmission);
		System.out.println("Number of doors of the Car: "+ doors);
		System.out.println("Number of tyres of the Car: "+ tyres);
	}
	/*
	 * To print acceleration of Car
	 */
	public void accelerate() {
		System.out.println("Car is moving forward.");
	}
	/*
	 * To print stoppage of Car
	 */
	public void brake() {
		System.out.println("Car has stopped.");
	}
}
