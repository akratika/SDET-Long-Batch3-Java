package javaActivity2_2;

import java.util.Arrays;

public class EncapsulationActivity {

	public static void main(String[] args) throws InterruptedException {
		
		Plane plane = new Plane(10);
		for(int i=1; i<=10; i++) {
			plane.onboard("Passenger" +i);
		}
		System.out.println("Plane take off at: " + plane.takeoff());
		System.out.println("People on plane: " + plane.getpassengers());
		Thread.sleep(5000);
		plane.land();
		System.out.println("Plane landing time: " + plane.getLastTimeLanded());
		if(plane.getpassengers().isEmpty()) {
			System.out.println("No people left on the plane after landing.");
		}else {
			System.out.println("People on the plane after landing: " + plane.getpassengers());
		}
		
	}

}
