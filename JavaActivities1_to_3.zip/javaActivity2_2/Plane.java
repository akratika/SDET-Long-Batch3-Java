package javaActivity2_2;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
 * Start by creating a class called Plane
 * Add a constructor that initializes the values of maxPassengers and the array passengers to an empty array
 * Change the access modifier of the four variables to private
 * Add the following methods to the Plane class:
 * onboard(): add passengers to the array using the add() method
 * takeOff(): returns the current date and time
 * land(): sets the value of lastTimeLanded to the current date and time. Also clear() the array
 * getLastTimeLanded(): returns the value of lastTimeLanded
 * getPassesngers(): returns the array of passengers
 */
public class Plane {
	private List<String> passengers;
    private int maxPassengers;
    private Date lastTimeTookOf;
    private Date lastTimeLanded;
    
	public Plane(int maxPassengers){
		this.maxPassengers = maxPassengers;
		this.passengers= new ArrayList<>();
	}
	
	public void onboard(String passenger) {
		this.passengers.add(passenger);
	}
	public Date takeoff() {
		this.lastTimeTookOf = new Date();
		return lastTimeTookOf;
	}
	public void land() {
		this.lastTimeLanded = new Date();
		this.passengers.clear();
	}
	public Date getLastTimeLanded() {
		return lastTimeLanded;
	}
	public List<String> getpassengers() {
		return passengers;
	}
	
}
