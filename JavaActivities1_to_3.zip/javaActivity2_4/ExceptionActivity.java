package javaActivity2_4;

public class ExceptionActivity {

	public static void main(String[] args) {
		try {
			ExceptionActivity.exceptionTest("This is a non-null string");
			ExceptionActivity.exceptionTest(null);
		}catch(CustomException cusex) {
			System.out.println("Catch Block Message: "+ cusex.getMessage());
		}

	}
	static void exceptionTest(String str) throws CustomException{
		if(str == null) {
			throw new CustomException("String value is null");
		}else
			System.out.println(str);
	}
}
