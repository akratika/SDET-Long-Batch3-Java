package javaActivity2_4;

class CustomException extends Exception {
	
	public String message = null;
	public CustomException(String message) {
		this.message = message;
	}
	@Override
	public String getMessage() {
		return message;
	}
	
}
