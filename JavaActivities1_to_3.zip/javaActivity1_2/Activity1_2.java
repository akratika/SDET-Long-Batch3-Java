package javaActivity1_2;

import java.util.Arrays;

import javax.naming.spi.DirStateFactory.Result;

public class Activity1_2 {

	public static void main(String[] args) {
		
		//Initialize Array
		int [] arr1 = {10, 77, 10, 54, -11, 10};
		System.out.println("Original array: "+ Arrays.toString(arr1));
		
		//Constants
		int searchnum = 10, finalSum = 30;
		
		//Print result
		System.out.println("Result(Sum is 30 or not): "+ result(arr1, searchnum, finalSum));

	}
	
	/*
	 * result method:
	 * input args: array, number to search, final Sum to check
	 @return boolean value of Sum is equal to input requirement or not
	 */
	public static boolean result(int[] array_numbers, int searchnum, int finalSum) {
		int sum = 0;
		for(int arr: array_numbers) {
			if(arr == searchnum) {
				sum += arr;
				if(sum > finalSum) {
					break;
				}
			}
		}
		return sum == finalSum;
	}

}
