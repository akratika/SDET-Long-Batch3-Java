package javaActivity3;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

public class Activity3_3B {

	public static void main(String[] args) {
		Deque<String> dq= new LinkedList<>();
		dq.add("Tiger");
		dq.add("Panther");
		dq.add("Peacock");
		dq.add("Rabbit");
		dq.add("Tortoise");
		dq.add("Cat");
		Iterator<String> it = dq.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			}
		System.out.println("Peek head element: "+ dq.peekFirst());
		System.out.println("Peek tail element: "+ dq.peekLast());
		if(dq.contains("Wolf")) {
			System.out.println("Wolf is present.");
		}else
			System.out.println("Wolf is not present.");
		dq.pollFirst();
		dq.pollLast();
		System.out.println("Updated size of the queue: "+ dq.size());
	}

}
