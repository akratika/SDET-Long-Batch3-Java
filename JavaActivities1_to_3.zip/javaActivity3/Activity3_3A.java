package javaActivity3;

import java.util.LinkedList;
import java.util.Queue;

public class Activity3_3A {

	public static void main(String[] args) {
		Queue<Integer> q = new LinkedList<>();
		
		for(int i=0; i<5; i++) {
			q.add(i);
		}
		System.out.println("Original Queue: "+ q);
		System.out.println("Removing a number from queue: "+ q.remove());
		System.out.println("First number in queue: "+q.peek());
		System.out.println("Size of queue: "+q.size());
		System.out.println("Updated queue: "+ q);
	}

}
