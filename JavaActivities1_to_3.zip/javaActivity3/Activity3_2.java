package javaActivity3;

import java.util.HashSet;
import java.util.Set;

public class Activity3_2 {

	public static void main(String[] args) {
		Set<String> hs = new HashSet<String>();
		hs.add("K");
		hs.add("V");
		hs.add("R");
		hs.add("I");
		hs.add("A");
		hs.add("N");
		System.out.println("Size of hashset: "+hs.size());
		System.out.println("Removing element N from hash set: "+ hs.remove("N"));
		if(hs.contains("Y")) {
			System.out.println("Removing element Y from hash set: "+ hs.remove("Y"));
		}else
			System.out.println("Element Y not present in hash set");
		
		System.out.println("Is V present in Set? "+ hs.contains("V"));
		System.out.println(hs);
	}

}
