package javaActivity3;

import java.util.ArrayList;
import java.util.List;

public class Activity3_1 {

	public static void main(String[] args) {
		List<String> myList = new ArrayList<String>();
		myList.add("James");
		myList.add("Bob");
		myList.add("Karen");
		myList.add("Kathy");
		myList.add("Michele");
		
		for(String arr: myList) {
			System.out.println(arr);
		}
		System.out.println("Third name in list: "+ myList.get(2));
		if(myList.contains("Karen")) {
			System.out.println("Karen exists in the list.");
		}
		System.out.println("Number of names in the list: "+ myList.size());
		myList.remove("Karen");
		System.out.println("Number of names in the list: "+ myList.size());

	}

}
