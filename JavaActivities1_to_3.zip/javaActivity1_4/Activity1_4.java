package javaActivity1_4;

import java.util.Arrays;

public class Activity1_4 {

	/*
	 * Initialize an array with numbers in random order
	 * Display the array before and after sorting.
	 */
	public static void main(String[] args) {
		int[] arr1 = {20,60,90,10,15};
		System.out.println("Default Array: "+ Arrays.toString(arr1) );
		insertionSortAscending(arr1);
		System.out.println("Ascending Order Array: "+ Arrays.toString(arr1) );

	}
	/*
	 * Use the insertion sort logic to sort the array in ascending order
	 */
	public static int[] insertionSortAscending(int[] arr) {
		for(int i=0; i< arr.length;i++) {
			for(int j=i+1; j<arr.length; j++) {
				if(arr[i] > arr[j]) {
					int keyElem= arr[i];
					arr[i]= arr[j];
					arr[j]= keyElem;
				}
			}
		}
		return arr;
	}
}
