package javaActivity2_1;

/*
 * Create an abstract class Book that has:
 * title of type String
 * an abstract method setTitle() that takes one String argument
 * a concrete method getTitle() that returns the value of title.
 */
abstract class Book {
	String title;
	
	//Set Title
	abstract void setTitle(String s);
		
	//get title
	String getTitle() {
		return title;
	}
}
