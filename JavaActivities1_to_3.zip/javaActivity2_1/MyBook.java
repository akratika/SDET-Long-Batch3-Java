package javaActivity2_1;

/*
 * Create another class that extends the abstract class called MyBook
 * MyBook defines the setTitle() method to assign the value of title as the argument.
 */
	class MyBook extends Book{
		//Define abstract method
		public void setTitle(String s) {
			title = s;
		}
	}
